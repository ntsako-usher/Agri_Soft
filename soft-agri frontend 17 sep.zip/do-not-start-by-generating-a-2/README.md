# Soft-Agri

Soft-Agri is a React/Vite frontend foundation for a calm, precision-agriculture monitoring experience.

## Run locally

```bash
npm install
npm run dev
```

The current phase includes the responsive application shell, design tokens, mock dashboard composition, navigation placeholders, and environment configuration. Backend services and richer page flows are intentionally introduced incrementally.
