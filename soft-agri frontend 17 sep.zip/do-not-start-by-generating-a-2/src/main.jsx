import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, NavLink, Route, Routes } from 'react-router-dom';
import {
  Activity, Bell, Check, ChevronDown, ChevronRight, CircleHelp, CloudRain,
  Droplets, Flame, Gauge, LayoutDashboard, Leaf, Lightbulb, Menu, Moon, MoreHorizontal,
  Radio, RefreshCw, Settings, ShieldAlert, ShieldCheck, Sun, Thermometer, Wifi, X
} from 'lucide-react';
import './styles.css';

const navItems = [
  { label: 'Overview', icon: LayoutDashboard, to: '/' },
  { label: 'Monitoring', icon: Activity, to: '/monitoring' },
  { label: 'History', icon: Gauge, to: '/history' },
  { label: 'Alerts', icon: Bell, to: '/alerts' },
  { label: 'Devices', icon: Wifi, to: '/devices' },
];

const readings = [
  { label: 'Temperature', value: '24.6°C', note: 'Normal', icon: Thermometer },
  { label: 'Humidity', value: '61%', note: 'Normal', icon: Droplets },
  { label: 'Pressure', value: '1012 hPa', note: 'Normal', icon: Gauge },
  { label: 'Rainfall', value: 'None', note: 'Last 24h', icon: CloudRain },
];

const alerts = [
  { title: 'Irrigation threshold reached', detail: 'North Field · 2h ago', tone: 'warning' },
  { title: 'Temperature above normal', detail: 'Greenhouse · 4h ago', tone: 'warning' },
  { title: 'Device offline', detail: 'Sensor 03 · 6h ago', tone: 'neutral' },
  { title: 'System check completed', detail: 'All devices · 12h ago', tone: 'healthy' },
];

const liveSensors = [
  { label: 'Air temperature', value: '24.6', unit: '°C', status: 'Normal', detail: 'Within range', icon: Thermometer, tone: 'healthy' },
  { label: 'Relative humidity', value: '61', unit: '%', status: 'Normal', detail: 'Stable', icon: Droplets, tone: 'healthy' },
  { label: 'Atmospheric pressure', value: '1012', unit: 'hPa', status: 'Normal', detail: 'Stable', icon: Gauge, tone: 'neutral' },
  { label: 'Light intensity', value: '68', unit: '%', status: 'Good', detail: 'Daylight', icon: Lightbulb, tone: 'healthy' },
  { label: 'Rain sensor', value: 'No', unit: ' rain', status: 'Dry', detail: 'No detection', icon: CloudRain, tone: 'neutral' },
  { label: 'Smoke detection', value: 'Clear', unit: '', status: 'Safe', detail: 'No smoke detected', icon: Flame, tone: 'healthy' },
  { label: 'Motion security', value: 'Clear', unit: '', status: 'Secure', detail: 'No intrusion', icon: ShieldAlert, tone: 'healthy' },
];

function Logo() {
  return <div className="brand"><span className="brand-mark"><Leaf size={17} /></span><span>SOFT-AGRI</span></div>;
}

function Sidebar({ open, onClose }) {
  return <aside className={`sidebar ${open ? 'is-open' : ''}`}>
    <div className="sidebar-top"><Logo /><button className="icon-button mobile-only" onClick={onClose} aria-label="Close navigation"><X size={18} /></button></div>
    <nav className="nav-list" aria-label="Primary navigation">
      {navItems.map(({ label, icon: Icon, to }) => <NavLink key={label} to={to} end={to === '/'} onClick={onClose} className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}><Icon size={17} strokeWidth={1.8} /><span>{label}</span></NavLink>)}
    </nav>
    <div className="sidebar-bottom">
      <NavLink to="/settings" onClick={onClose} className="nav-item"><Settings size={17} strokeWidth={1.8} /><span>Settings</span></NavLink>
      <div className="farm-online"><span className="status-dot healthy" /><div><strong>Farm Online</strong><small>All systems operational</small></div></div>
    </div>
  </aside>;
}

function Header({ onMenu, dark, onThemeToggle }) {
  return <header className="topbar"><button className="icon-button mobile-only" onClick={onMenu} aria-label="Open navigation"><Menu size={20} /></button><div><p className="eyebrow">Thursday, April 24, 2025</p><h1>Good evening, Musa</h1><p className="subtle">Here’s what’s happening on your farm today.</p></div><div className="topbar-actions"><span className="system-pill"><span className="status-dot healthy" />All systems normal</span><button className="theme-toggle" onClick={onThemeToggle} aria-label={`Switch to ${dark ? 'light' : 'dark'} mode`} title={`Switch to ${dark ? 'light' : 'dark'} mode`}><Sun size={14} /><span className="theme-toggle-knob">{dark ? <Moon size={13} /> : <Sun size={13} />}</span><Moon size={14} /></button><button className="icon-button" aria-label="Help"><CircleHelp size={18} /></button><button className="avatar" aria-label="Open profile">M</button></div></header>;
}

function Card({ className = '', children }) { return <section className={`card ${className}`}>{children}</section>; }

function MoistureCard() {
  return <Card className="moisture-card"><div className="card-heading"><div><p className="kicker"><Leaf size={15} /> Soil Moisture</p><p className="subtle">North Field</p></div><span className="range-pill">Target 35% — 60%</span></div><div className="metric-row"><div><strong className="hero-metric">42<span>%</span></strong><p className="metric-status"><span className="status-dot healthy" />Optimal <ChevronDown size={13} /></p></div><MiniChart /></div></Card>;
}

function MiniChart() {
  return <div className="mini-chart" aria-label="Soil moisture trend"><svg viewBox="0 0 430 120" role="img"><defs><linearGradient id="chartFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#557a5b" stopOpacity=".22" /><stop offset="1" stopColor="#557a5b" stopOpacity="0" /></linearGradient></defs><path className="chart-area" d="M0 86 C35 77, 48 71, 78 68 S118 48, 150 64 S188 71, 218 51 S258 58, 287 55 S326 76, 351 54 S388 33, 430 42 L430 120 L0 120 Z" /><path className="chart-line" d="M0 86 C35 77, 48 71, 78 68 S118 48, 150 64 S188 71, 218 51 S258 58, 287 55 S326 76, 351 54 S388 33, 430 42" /></svg><div className="chart-labels"><span>12 AM</span><span>6 AM</span><span>12 PM</span><span>6 PM</span><span>Now</span></div></div>;
}

function StatusCard() {
  return <Card className="status-card"><div className="card-heading"><p className="kicker"><ShieldCheck size={16} /> Farm Status</p><MoreHorizontal size={18} className="muted-icon" /></div><div className="status-title"><span className="status-ring"><Check size={16} /></span>All systems normal</div><div className="status-list"><span><ShieldCheck size={14} />4 devices online</span><span><ShieldCheck size={14} />No active threats</span><span><ShieldCheck size={14} />Irrigation system: Off <ChevronRight size={14} /></span></div></Card>;
}

function FieldCard() { return <Card className="field-card"><div className="field-image"><div className="field-overlay"><strong>North Field</strong><span>12.4 ha</span></div><button className="field-action" aria-label="Open North Field"><ChevronRight size={16} /></button></div></Card>; }

function Environment() { return <Card className="environment"><div className="card-heading"><p className="kicker"><Leaf size={15} /> Environmental Conditions</p></div><div className="environment-grid">{readings.map(({ label, value, note, icon: Icon }) => <div className="environment-item" key={label}><span className="sensor-icon"><Icon size={17} /></span><div><span className="subtle">{label}</span><strong>{value}</strong><small>{note}</small></div></div>)}</div></Card>; }

function TrendCard() { return <Card className="trend-card"><div className="card-heading"><p className="kicker"><Leaf size={15} /> Soil Moisture Trend</p><button className="select-button">Last 7 days <ChevronDown size={14} /></button></div><div className="trend-chart"><div className="grid-lines"><span>80%</span><span>60%</span><span>40%</span><span>20%</span></div><svg viewBox="0 0 720 130" preserveAspectRatio="none"><defs><linearGradient id="trendFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#557a5b" stopOpacity=".2" /><stop offset="1" stopColor="#557a5b" stopOpacity="0" /></linearGradient></defs><path className="chart-area" d="M0 65 C46 72, 68 62, 95 70 S147 45, 186 53 S240 43, 275 51 S322 37, 354 52 S402 45, 437 65 S482 76, 512 69 S548 81, 581 70 S628 83, 659 71 S694 62, 720 55 L720 130 L0 130Z" /><path className="chart-line" d="M0 65 C46 72, 68 62, 95 70 S147 45, 186 53 S240 43, 275 51 S322 37, 354 52 S402 45, 437 65 S482 76, 512 69 S548 81, 581 70 S628 83, 659 71 S694 62, 720 55" /></svg></div><div className="chart-labels trend-labels"><span>Apr 18</span><span>Apr 19</span><span>Apr 20</span><span>Apr 21</span><span>Apr 22</span><span>Apr 23</span><span>Apr 24</span></div></Card>; }

function IrrigationCard() { return <Card className="irrigation-card"><div className="card-heading"><p className="kicker"><Droplets size={16} /> Irrigation Control</p><span className="toggle" aria-label="Irrigation is off"><span /></span></div><div className="irrigation-state">OFF</div><p className="subtle">Automatic mode</p><p className="tiny-note">Next scheduled run: Apr 25, 06:00</p><button className="secondary-button">Settings</button></Card>; }

function AlertsPanel() { return <Card className="alerts-panel"><div className="card-heading"><p className="kicker">Recent Alerts</p><button className="text-button">View all</button></div><div className="alert-list">{alerts.map(alert => <div className="alert-row" key={alert.title}><span className={`alert-dot ${alert.tone}`} /><div><strong>{alert.title}</strong><small>{alert.detail}</small></div></div>)}</div></Card>; }

function QuickActions() { return <Card className="quick-actions"><div className="card-heading"><p className="kicker">Quick Actions</p></div>{['View Camera Feed', 'Check Device Status', 'View Reports'].map((action, index) => <button className="quick-action" key={action}><span className="quick-icon">{index === 0 ? <Activity size={15} /> : index === 1 ? <Wifi size={15} /> : <LayoutDashboard size={15} />}</span>{action}<ChevronRight size={14} /></button>)}</Card>; }

function Dashboard() { return <><div className="page-intro"><div><p className="eyebrow">North Field · Device cluster 01</p><h2>Farm overview</h2></div><button className="farm-selector">North Field <ChevronDown size={15} /></button></div><div className="dashboard-grid"><div className="main-column"><div className="hero-grid"><MoistureCard /><StatusCard /><FieldCard /></div><Environment /><div className="lower-grid"><TrendCard /><IrrigationCard /></div></div><aside className="right-column"><AlertsPanel /><QuickActions /></aside></div></>; }

function SensorTile({ sensor }) {
  const Icon = sensor.icon;
  return <article className="live-sensor-tile"><span className={`live-sensor-icon ${sensor.tone}`}><Icon size={18} /></span><div className="live-sensor-copy"><p>{sensor.label}</p><span className="live-detail">{sensor.detail} · Updated just now</span></div><strong>{sensor.value}<small>{sensor.unit}</small></strong><span className={`live-badge ${sensor.tone}`}><span />{sensor.status}</span></article>;
}

function LiveMonitoring() {
  const [updated, setUpdated] = useState('just now');
  return <div className="monitoring-page"><div className="monitoring-header"><div><p className="eyebrow">North Field · 4 connected devices</p><h2>Live monitoring</h2><p className="subtle">A clear, real-time view of your field conditions.</p></div><div className="monitoring-actions"><span className="live-connection"><span className="live-pulse" />Live connection</span><button className="refresh-button" onClick={() => setUpdated('just now')}><RefreshCw size={15} />Refresh</button></div></div><section className="live-hero"><div className="live-hero-copy"><span className="live-kicker"><Radio size={14} />Current field signal</span><p>Soil moisture is <strong>optimal</strong></p><span>42% moisture is within the 35%–60% healthy range.</span><div className="live-hero-meta"><span><span className="status-dot healthy" />Updated {updated}</span><span>Sensor 01 · Online</span></div></div><div className="live-gauge"><div className="gauge-caption"><span>Soil moisture</span><strong>42%</strong></div><div className="gauge-track"><span className="gauge-safe" /><span className="gauge-value" /></div><div className="gauge-labels"><span>0%</span><span>35%</span><span>60%</span><span>100%</span></div></div></section><section className="live-section-heading"><div><h3>Field sensors</h3><p>Live readings from North Field Sensor 01</p></div><span>Last packet received 5 seconds ago</span></section><div className="live-sensor-grid">{liveSensors.map(sensor => <SensorTile key={sensor.label} sensor={sensor} />)}</div><div className="monitoring-lower"><section className="card device-health"><div className="card-heading"><div><p className="kicker"><Wifi size={16} /> Device health</p><p className="subtle">Connection across North Field</p></div><span className="live-badge healthy"><span />4 online</span></div><div className="device-row"><span className="device-orb"><Radio size={16} /></span><div><strong>North Field Sensor 01</strong><small>Primary environment sensor · Signal excellent</small></div><span className="device-time">Updated 5 sec ago</span></div><div className="device-row"><span className="device-orb"><Droplets size={16} /></span><div><strong>Irrigation Controller</strong><small>Automatic mode · Pump standing by</small></div><span className="device-time">Updated 8 sec ago</span></div></section><section className="card live-irrigation"><div className="card-heading"><p className="kicker"><Droplets size={16} /> Irrigation state</p><span className="toggle"><span /></span></div><strong>Standby</strong><p>Automation is ready. Watering starts only when the backend threshold rules require it.</p><span className="live-detail">Next schedule: Tomorrow, 06:00</span></section></div></div>;
}

function Placeholder({ title }) { return <div className="placeholder"><span className="placeholder-icon"><Leaf size={20} /></span><h2>{title}</h2><p>This section is part of the next implementation phase. The app shell and design system are ready for it.</p></div>; }

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [dark, setDark] = useState(() => window.localStorage.getItem('soft-agri-theme') === 'dark');
  useEffect(() => { window.localStorage.setItem('soft-agri-theme', dark ? 'dark' : 'light'); }, [dark]);
  return <div className={`app-shell ${dark ? 'theme-dark' : ''}`}><Sidebar open={menuOpen} onClose={() => setMenuOpen(false)} />{menuOpen && <button className="scrim" onClick={() => setMenuOpen(false)} aria-label="Close navigation" /> }<main className="main"><Header onMenu={() => setMenuOpen(true)} dark={dark} onThemeToggle={() => setDark(current => !current)} /><div className="content"><Routes><Route path="/" element={<Dashboard />} /><Route path="/monitoring" element={<LiveMonitoring />} /><Route path="/history" element={<Placeholder title="Historical data" />} /><Route path="/alerts" element={<Placeholder title="Alerts" />} /><Route path="/devices" element={<Placeholder title="Devices" />} /><Route path="/settings" element={<Placeholder title="Settings" />} /></Routes></div></main></div>;
}

createRoot(document.getElementById('root')).render(<React.StrictMode><BrowserRouter><App /></BrowserRouter></React.StrictMode>);
