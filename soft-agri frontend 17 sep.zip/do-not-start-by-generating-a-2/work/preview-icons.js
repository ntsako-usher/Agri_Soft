const iconPaths = {
  leaf: '<path d="M20 4C12 4 5 8 5 16c0 2 .7 3.6 1.8 4.9C15.4 20.6 20 14.3 20 4Z"/><path d="M4 21c4.3-5 8.2-7.9 14-11"/>',
  overview: '<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/>',
  monitoring: '<path d="M3 12h4l2.2-6 4.1 12 2.5-7H21"/>',
  history: '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/><path d="M12 7v5l3 2"/>',
  alerts: '<path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 22h4"/>',
  devices: '<rect x="5" y="4" width="14" height="16" rx="2"/><path d="M9 8h6M9 12h.01M15 12h.01M9 16h6"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.2 2.2-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5v.2h-3.1v-.2a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1-2.2-2.2.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H5v-3.1h.2a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.9l-.1-.1 2.2-2.2.1.1a1.7 1.7 0 0 0 1.9.3 1.7 1.7 0 0 0 1-1.5V4h3.1v.2a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1 2.2 2.2-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.5 1h.2V14h-.2a1.7 1.7 0 0 0-1.5 1Z"/>',
  temperature: '<path d="M14 14.8V5a2 2 0 0 0-4 0v9.8a4 4 0 1 0 4 0Z"/><path d="M12 9v7"/>',
  humidity: '<path d="M12 3s6 6.4 6 11a6 6 0 0 1-12 0c0-4.6 6-11 6-11Z"/>',
  pressure: '<path d="M4 14a8 8 0 1 1 16 0"/><path d="m12 14 3-3"/><path d="M4 18h16"/>',
  light: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  rain: '<path d="M7 18a4 4 0 1 1 .6-7.9A5 5 0 0 1 17 12a3 3 0 0 1-1 5.8H7Z"/><path d="m8 20-1 2m5-2-1 2m5-2-1 2"/>',
  smoke: '<path d="M9 20c-2-1-3-3-3-5 0-4 4-6 5-10 4 3 7 5 7 9 0 4-2.5 6-6 6"/><path d="M12 20c-1.5-1.2-2-2.7-1.5-4.5"/>',
  security: '<path d="M12 3 20 7v5c0 5-3.4 8-8 9-4.6-1-8-4-8-9V7l8-4Z"/><path d="m9 12 2 2 4-4"/>',
  radio: '<circle cx="12" cy="12" r="2"/><path d="M7.1 7.1a7 7 0 0 0 0 9.8M16.9 7.1a7 7 0 0 1 0 9.8M3.6 3.6a12 12 0 0 0 0 16.8M20.4 3.6a12 12 0 0 1 0 16.8"/>'
};

const icon = (name) => `<svg class="preview-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${iconPaths[name]}</svg>`;
const navIcons = { Overview: 'overview', Monitoring: 'monitoring', History: 'history', Alerts: 'alerts', Devices: 'devices', Settings: 'settings' };
const sensorIcons = { 'Air temperature': 'temperature', 'Relative humidity': 'humidity', 'Atmospheric pressure': 'pressure', 'Light intensity': 'light', 'Rain sensor': 'rain', 'Smoke detection': 'smoke', 'Motion security': 'security' };

document.querySelectorAll('.brand-mark').forEach((el) => { el.innerHTML = icon('leaf'); });
document.querySelectorAll('.nav-item').forEach((el) => {
  const label = el.textContent.trim().replace(/^[^A-Za-z]+/, '');
  if (navIcons[label]) el.innerHTML = `${icon(navIcons[label])}<span>${label}</span>`;
});
document.querySelectorAll('.live-sensor-tile').forEach((tile) => {
  const label = tile.querySelector('p')?.textContent.trim();
  const slot = tile.querySelector('.live-sensor-icon');
  if (slot && sensorIcons[label]) slot.innerHTML = icon(sensorIcons[label]);
});
document.querySelectorAll('.device-orb').forEach((el, index) => { el.innerHTML = icon(index ? 'humidity' : 'radio'); });
document.querySelectorAll('.kicker, .live-kicker').forEach((el) => {
  const label = el.textContent.trim().replace(/^[^A-Za-z]+/, '');
  const name = /Device health/.test(label) ? 'devices' : /Irrigation/.test(label) ? 'humidity' : /signal/.test(label) ? 'radio' : null;
  if (name) el.innerHTML = `${icon(name)}${label}`;
});
