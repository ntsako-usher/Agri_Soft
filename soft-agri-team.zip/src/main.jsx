import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, NavLink, Route, Routes, useNavigate } from 'react-router-dom';
import {
  Activity, Bell, CalendarRange, Check, ChevronDown, ChevronRight, CircleHelp, CloudRain,
  Droplets, Flame, Gauge, LayoutDashboard, Leaf, Lightbulb, Menu, Moon, MoreHorizontal,
  Radio, RefreshCw, Settings, ShieldAlert, ShieldCheck, Sun, Thermometer, TrendingUp, Wifi, X
} from 'lucide-react';
import './styles.css';

const navItems = [
  { label: 'Overview', icon: LayoutDashboard, to: '/' },
  { label: 'Monitoring', icon: Activity, to: '/monitoring' },
  { label: 'History', icon: Gauge, to: '/history' },
  { label: 'Alerts', icon: Bell, to: '/alerts' },
  { label: 'Devices', icon: Wifi, to: '/devices' },
];

const readings = [
  { label: 'Temperature', value: '24.6°C', note: 'Normal', icon: Thermometer },
  { label: 'Humidity', value: '61%', note: 'Normal', icon: Droplets },
  { label: 'Pressure', value: '1012 hPa', note: 'Normal', icon: Gauge },
  { label: 'Rainfall', value: 'None', note: 'Last 24h', icon: CloudRain },
];

const alerts = [
  { title: 'Irrigation threshold reached', detail: 'North Field · 2h ago', tone: 'warning' },
  { title: 'Temperature above normal', detail: 'Greenhouse · 4h ago', tone: 'warning' },
  { title: 'Device offline', detail: 'Sensor 03 · 6h ago', tone: 'neutral' },
  { title: 'System check completed', detail: 'All devices · 12h ago', tone: 'healthy' },
];

const liveSensors = [
  { label: 'Air temperature', value: '24.6', unit: '°C', status: 'Normal', detail: 'Within range', icon: Thermometer, tone: 'healthy' },
  { label: 'Relative humidity', value: '61', unit: '%', status: 'Normal', detail: 'Stable', icon: Droplets, tone: 'healthy' },
  { label: 'Atmospheric pressure', value: '1012', unit: 'hPa', status: 'Normal', detail: 'Stable', icon: Gauge, tone: 'neutral' },
  { label: 'Light intensity', value: '68', unit: '%', status: 'Good', detail: 'Daylight', icon: Lightbulb, tone: 'healthy' },
  { label: 'Rain sensor', value: 'No', unit: ' rain', status: 'Dry', detail: 'No detection', icon: CloudRain, tone: 'neutral' },
  { label: 'Smoke detection', value: 'Clear', unit: '', status: 'Safe', detail: 'No smoke detected', icon: Flame, tone: 'healthy' },
  { label: 'Motion security', value: 'Clear', unit: '', status: 'Secure', detail: 'No intrusion', icon: ShieldAlert, tone: 'healthy' },
];

const historyRanges = [
  { key: '24h', label: 'Last 24 hours' },
  { key: '7d', label: 'Last 7 days' },
  { key: '30d', label: 'Last 30 days' },
];

const historyFields = ['North Field', 'South Field', 'Greenhouse'];

const historyMetrics = {
  soilMoisture: { label: 'Soil moisture', unit: '%', accessor: 'soilMoisture', color: '#557a5b' },
  temperature: { label: 'Temperature', unit: '°C', accessor: 'temperature', color: '#b58a45' },
  humidity: { label: 'Humidity', unit: '%', accessor: 'humidity', color: '#6a8bc8' },
};

function buildHistoricalData() {
  const records = [];
  const start = new Date();
  start.setHours(0, 0, 0, 0);

  for (let day = 0; day < 45; day += 1) {
    for (let slot = 0; slot < 8; slot += 1) {
      const timestamp = new Date(start.getTime() - (44 - day) * 24 * 60 * 60 * 1000 + slot * 3 * 60 * 60 * 1000);
      const soilMoisture = 36 + Math.sin((day + slot / 2) * 0.8) * 13 + (slot % 3 === 0 ? 4 : 0);
      const temperature = 22 + Math.cos((day + slot) * 0.9) * 5 + (slot > 5 ? 1.5 : 0);
      const humidity = 58 + Math.sin((day + slot) * 0.7) * 12;
      const pressure = 1008 + Math.cos(day * 0.5 + slot) * 6;
      const light = 18 + Math.sin((day + slot) * 0.7) * 24 + (slot > 3 && slot < 7 ? 25 : 6);
      const rainfall = (slot === 2 || slot === 6) && day % 5 !== 0 ? 6 : (slot === 5 && day % 6 === 0 ? 12 : 0);

      records.push({
        id: `${day}-${slot}`,
        date: timestamp.toISOString().slice(0, 10),
        time: timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }),
        field: historyFields[day % historyFields.length],
        device: `Sensor ${((day + slot) % 5) + 1}`,
        soilMoisture: Number(Math.max(22, Math.min(62, soilMoisture)).toFixed(1)),
        temperature: Number(Math.max(16, Math.min(33, temperature)).toFixed(1)),
        humidity: Number(Math.max(35, Math.min(82, humidity)).toFixed(1)),
        pressure: Number(Math.max(995, Math.min(1021, pressure)).toFixed(1)),
        light: Number(Math.max(0, Math.min(100, light)).toFixed(1)),
        rainfall: Number(rainfall.toFixed(1)),
      });
    }
  }

  return records;
}

const mockHistoryData = buildHistoricalData();

const alertFields = ['North Field', 'South Field', 'Greenhouse', 'Irrigation Bay'];
const alertSeverityOptions = ['all', 'critical', 'warning', 'informational'];
const alertStatusOptions = ['all', 'active', 'resolved'];

const mockAlertData = [
  {
    id: 1,
    title: 'Soil moisture below threshold',
    severity: 'critical',
    status: 'active',
    field: 'North Field',
    device: 'Sensor 01',
    date: '2025-04-24',
    time: '06:32',
    source: 'Soil probe',
    description: 'Moisture dropped to 22.4% in the north irrigation zone. This is below the recommended 35% minimum for healthy crop growth.',
    action: 'Irrigation was triggered automatically.',
  },
  {
    id: 2,
    title: 'High temperature warning',
    severity: 'warning',
    status: 'active',
    field: 'Greenhouse',
    device: 'Climate Sensor 02',
    date: '2025-04-24',
    time: '14:12',
    source: 'Temperature sensor',
    description: 'Temperature has remained above 30°C for the past hour. Ventilation should be checked to prevent plant stress.',
    action: 'Cooling cycle recommended.',
  },
  {
    id: 3,
    title: 'Heavy rainfall detected',
    severity: 'informational',
    status: 'resolved',
    field: 'South Field',
    device: 'Rain gauge 04',
    date: '2025-04-23',
    time: '20:45',
    source: 'Weather station',
    description: 'Moderate rain was detected across the south plot. Soil moisture has improved after the rainfall event.',
    action: 'Irrigation schedule was paused.',
  },
  {
    id: 4,
    title: 'Smoke / fire detected',
    severity: 'critical',
    status: 'active',
    field: 'North Field',
    device: 'Safety sensor 07',
    date: '2025-04-24',
    time: '03:18',
    source: 'Smoke detector',
    description: 'Smoke density exceeded the safe threshold for the equipment shed. Immediate inspection is recommended.',
    action: 'Alarm remains active. Emergency response recommended.',
  },
  {
    id: 5,
    title: 'Motion detected near fence',
    severity: 'critical',
    status: 'active',
    field: 'Irrigation Bay',
    device: 'Security camera 03',
    date: '2025-04-24',
    time: '02:05',
    source: 'Motion sensor',
    description: 'Movement was detected near the west boundary fence during the early morning hours.',
    action: 'Scout the area and verify the perimeter.',
  },
  {
    id: 6,
    title: 'Device offline',
    severity: 'warning',
    status: 'resolved',
    field: 'Greenhouse',
    device: 'Sensor 09',
    date: '2025-04-22',
    time: '19:10',
    source: 'System health',
    description: 'One greenhouse sensor stopped transmitting data for 18 minutes before reconnecting automatically.',
    action: 'Signal restored after network retry.',
  },
  {
    id: 7,
    title: 'Irrigation cycle completed',
    severity: 'informational',
    status: 'resolved',
    field: 'North Field',
    device: 'Valve 02',
    date: '2025-04-24',
    time: '05:00',
    source: 'Irrigation controller',
    description: 'A scheduled irrigation cycle has finished successfully and no abnormalities were detected.',
    action: 'No action required.',
  },
  {
    id: 8,
    title: 'Battery low on sensor node',
    severity: 'warning',
    status: 'active',
    field: 'South Field',
    device: 'Node 14',
    date: '2025-04-24',
    time: '12:48',
    source: 'Hardware monitor',
    description: 'The sensor node battery has dropped below 18%. Replacement should be scheduled soon.',
    action: 'Plan a field maintenance visit this week.',
  },
];

const mockDeviceData = [
  {
    id: 'DF-NS-01',
    name: 'North Field Sensor 01',
    type: 'Soil & climate sensor',
    field: 'North Field',
    status: 'online',
    signal: '92%',
    lastSeen: '2 min ago',
    battery: '87%',
    health: 'Stable',
    capabilities: ['Soil moisture', 'Temperature', 'Humidity'],
    operatingState: 'Monitoring',
    notes: 'Primary sensor on the north plot. Reporting every 5 minutes.',
  },
  {
    id: 'IC-IR-02',
    name: 'Irrigation Controller',
    type: 'Automation controller',
    field: 'North Field',
    status: 'online',
    signal: '88%',
    lastSeen: '1 min ago',
    battery: 'N/A',
    health: 'Healthy',
    capabilities: ['Valve control', 'Schedule logic', 'Flow checks'],
    operatingState: 'Idle',
    notes: 'Automated watering is active for scheduled cycles only.',
  },
  {
    id: 'SM-SEC-03',
    name: 'Security / Motion Sensor',
    type: 'Perimeter sensor',
    field: 'Irrigation Bay',
    status: 'needs-attention',
    signal: '64%',
    lastSeen: '9 min ago',
    battery: '31%',
    health: 'Check battery',
    capabilities: ['Motion detection', 'Boundary alerting'],
    operatingState: 'Alert watch',
    notes: 'Battery is low and a replacement is recommended soon.',
  },
  {
    id: 'WE-ENV-04',
    name: 'Weather / Environmental Sensor',
    type: 'Weather station',
    field: 'South Field',
    status: 'online',
    signal: '95%',
    lastSeen: '4 min ago',
    battery: '76%',
    health: 'Strong',
    capabilities: ['Rain detection', 'Wind', 'Pressure'],
    operatingState: 'Monitoring',
    notes: 'Reliable weather readings across the south field.',
  },
  {
    id: 'SA-SM-05',
    name: 'Smoke Safety Sensor',
    type: 'Safety device',
    field: 'North Field',
    status: 'offline',
    signal: '0%',
    lastSeen: '2 hours ago',
    battery: '14%',
    health: 'Offline',
    capabilities: ['Smoke detection', 'Alarm trigger'],
    operatingState: 'Reconnect required',
    notes: 'This safety sensor is offline and should be inspected or reconnected.',
  },
  {
    id: 'GH-CL-06',
    name: 'Greenhouse Climate Sensor',
    type: 'Climate monitor',
    field: 'Greenhouse',
    status: 'online',
    signal: '81%',
    lastSeen: '3 min ago',
    battery: '58%',
    health: 'Normal',
    capabilities: ['Temperature', 'Humidity', 'Ventilation'],
    operatingState: 'Active',
    notes: 'Humidity and temperature are tracking within expected greenhouse values.',
  },
];

function Logo() {
  return <div className="brand"><span className="brand-mark"><Leaf size={17} /></span><span>SOFT-AGRI</span></div>;
}

function Sidebar({ open, onClose }) {
  return <aside className={`sidebar ${open ? 'is-open' : ''}`}>
    <div className="sidebar-top"><Logo /><button className="icon-button mobile-only" onClick={onClose} aria-label="Close navigation"><X size={18} /></button></div>
    <nav className="nav-list" aria-label="Primary navigation">
      {navItems.map(({ label, icon: Icon, to }) => <NavLink key={label} to={to} end={to === '/'} onClick={onClose} className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}><Icon size={17} strokeWidth={1.8} /><span>{label}</span></NavLink>)}
    </nav>
    <div className="sidebar-bottom">
      <NavLink to="/settings" onClick={onClose} className="nav-item"><Settings size={17} strokeWidth={1.8} /><span>Settings</span></NavLink>
      <div className="farm-online"><span className="status-dot healthy" /><div><strong>Farm Online</strong><small>All systems operational</small></div></div>
    </div>
  </aside>;
}

function Header({ onMenu, dark, onThemeToggle, helpOpen, profileOpen, onHelpToggle, onProfileToggle, onClosePanels }) {
  return (
    <header className="topbar">
      <button className="icon-button mobile-only" onClick={onMenu} aria-label="Open navigation">
        <Menu size={20} />
      </button>

      <div>
        <p className="eyebrow">Thursday, April 24, 2025</p>
        <h1>Good evening, Musa</h1>
        <p className="subtle">Here’s what’s happening on your farm today.</p>
      </div>

      <div className="topbar-actions">
        <span className="system-pill">
          <span className="status-dot healthy" />
          All systems normal
        </span>

        <button
          className="theme-toggle"
          onClick={onThemeToggle}
          aria-label={`Switch to ${dark ? 'light' : 'dark'} mode`}
          title={`Switch to ${dark ? 'light' : 'dark'} mode`}
        >
          <Sun size={14} />
          <span className="theme-toggle-knob">{dark ? <Moon size={13} /> : <Sun size={13} />}</span>
          <Moon size={14} />
        </button>

        <div className="header-actions-wrap">
          <button
            className="icon-button"
            aria-label="Help"
            onClick={() => {
              onClosePanels();
              onHelpToggle();
            }}
          >
            <CircleHelp size={18} />
          </button>

          {helpOpen && (
            <div className="header-popover panel-card">
              <div className="panel-header">
                <strong>Soft-Agri help</strong>
                <button type="button" className="small-close" onClick={onClosePanels} aria-label="Close help panel">Close</button>
              </div>
              <ul className="help-list">
                <li>Use the sidebar to switch between Overview, Monitoring, History, Alerts, and Devices.</li>
                <li>Use the farm selector to switch the active field context.</li>
                <li>Settings lets you locally adjust irrigation and alert preferences for the current field.</li>
              </ul>
            </div>
          )}
        </div>

        <div className="header-actions-wrap">
          <button
            className="avatar"
            aria-label="Open profile menu"
            onClick={() => {
              onClosePanels();
              onProfileToggle();
            }}
          >
            M
          </button>

          {profileOpen && (
            <div className="header-popover panel-card">
              <div className="panel-header">
                <strong>Profile</strong>
                <button type="button" className="small-close" onClick={onClosePanels} aria-label="Close profile menu">Close</button>
              </div>
              <div className="profile-row">
                <span className="profile-pill">M</span>
                <div>
                  <strong>Musa</strong>
                  <small>Farm manager</small>
                </div>
              </div>
              <div className="profile-actions">
                <button type="button" className="secondary-button" onClick={onClosePanels}>View account</button>
                <button type="button" className="ghost-button" onClick={onClosePanels}>Sign out</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}

function Card({ className = '', children }) { return <section className={`card ${className}`}>{children}</section>; }

function MoistureCard() {
  return <Card className="moisture-card"><div className="card-heading"><div><p className="kicker"><Leaf size={15} /> Soil Moisture</p><p className="subtle">North Field</p></div><span className="range-pill">Target 35% — 60%</span></div><div className="metric-row"><div><strong className="hero-metric">42<span>%</span></strong><p className="metric-status"><span className="status-dot healthy" />Optimal <ChevronDown size={13} /></p></div><MiniChart /></div></Card>;
}

function MiniChart() {
  return <div className="mini-chart" aria-label="Soil moisture trend"><svg viewBox="0 0 430 120" role="img"><defs><linearGradient id="chartFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#557a5b" stopOpacity=".22" /><stop offset="1" stopColor="#557a5b" stopOpacity="0" /></linearGradient></defs><path className="chart-area" d="M0 86 C35 77, 48 71, 78 68 S118 48, 150 64 S188 71, 218 51 S258 58, 287 55 S326 76, 351 54 S388 33, 430 42 L430 120 L0 120 Z" /><path className="chart-line" d="M0 86 C35 77, 48 71, 78 68 S118 48, 150 64 S188 71, 218 51 S258 58, 287 55 S326 76, 351 54 S388 33, 430 42" /></svg><div className="chart-labels"><span>12 AM</span><span>6 AM</span><span>12 PM</span><span>6 PM</span><span>Now</span></div></div>;
}

function StatusCard() {
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();

  return <Card className="status-card"><div className="card-heading"><p className="kicker"><ShieldCheck size={16} /> Farm Status</p><button type="button" className="icon-button subtle-button" aria-label="Open farm status actions" onClick={() => setMenuOpen((currentValue) => !currentValue)}><MoreHorizontal size={18} className="muted-icon" /></button>{menuOpen && <div className="action-menu"><button type="button" onClick={() => { setMenuOpen(false); navigate('/alerts'); }}>View alerts</button><button type="button" onClick={() => { setMenuOpen(false); navigate('/devices'); }}>Check devices</button><button type="button" onClick={() => { setMenuOpen(false); navigate('/history'); }}>Open reports</button></div>}</div><div className="status-title"><span className="status-ring"><Check size={16} /></span>All systems normal</div><div className="status-list"><span><ShieldCheck size={14} />4 devices online</span><span><ShieldCheck size={14} />No active threats</span><span><ShieldCheck size={14} />Irrigation system: Off <ChevronRight size={14} /></span></div></Card>;
}

function FieldCard({ fieldName = 'North Field', onSelect }) {
  return <Card className="field-card"><div className="field-image"><div className="field-overlay"><strong>{fieldName}</strong><span>12.4 ha</span></div><button className="field-action" aria-label={`Open ${fieldName}`} onClick={onSelect}><ChevronRight size={16} /></button></div></Card>;
}

function Environment() { return <Card className="environment"><div className="card-heading"><p className="kicker"><Leaf size={15} /> Environmental Conditions</p></div><div className="environment-grid">{readings.map(({ label, value, note, icon: Icon }) => <div className="environment-item" key={label}><span className="sensor-icon"><Icon size={17} /></span><div><span className="subtle">{label}</span><strong>{value}</strong><small>{note}</small></div></div>)}</div></Card>; }

function TrendCard() {
  const [isMenuOpen, setMenuOpen] = useState(false);
  const [windowLabel, setWindowLabel] = useState('Last 7 days');

  return <Card className="trend-card"><div className="card-heading"><p className="kicker"><Leaf size={15} /> Soil Moisture Trend</p><button type="button" className="select-button" aria-expanded={isMenuOpen} aria-label="Open soil trend selection" onClick={() => setMenuOpen((currentValue) => !currentValue)}>{windowLabel} <ChevronDown size={14} /></button>{isMenuOpen && <div className="action-menu compact-menu"><button type="button" onClick={() => { setWindowLabel('Last 24 hours'); setMenuOpen(false); }}>Last 24 hours</button><button type="button" onClick={() => { setWindowLabel('Last 7 days'); setMenuOpen(false); }}>Last 7 days</button><button type="button" onClick={() => { setWindowLabel('Last 30 days'); setMenuOpen(false); }}>Last 30 days</button></div>}</div><div className="trend-chart"><div className="grid-lines"><span>80%</span><span>60%</span><span>40%</span><span>20%</span></div><svg viewBox="0 0 720 130" preserveAspectRatio="none"><defs><linearGradient id="trendFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#557a5b" stopOpacity=".2" /><stop offset="1" stopColor="#557a5b" stopOpacity="0" /></linearGradient></defs><path className="chart-area" d="M0 65 C46 72, 68 62, 95 70 S147 45, 186 53 S240 43, 275 51 S322 37, 354 52 S402 45, 437 65 S482 76, 512 69 S548 81, 581 70 S628 83, 659 71 S694 62, 720 55 L720 130 L0 130Z" /><path className="chart-line" d="M0 65 C46 72, 68 62, 95 70 S147 45, 186 53 S240 43, 275 51 S322 37, 354 52 S402 45, 437 65 S482 76, 512 69 S548 81, 581 70 S628 83, 659 71 S694 62, 720 55" /></svg></div><div className="chart-labels trend-labels"><span>Apr 18</span><span>Apr 19</span><span>Apr 20</span><span>Apr 21</span><span>Apr 22</span><span>Apr 23</span><span>Apr 24</span></div></Card>;
}

function IrrigationCard({ onOpenSettings }) {
  const [isOn, setIsOn] = useState(false);
  return <Card className="irrigation-card"><div className="card-heading"><p className="kicker"><Droplets size={16} /> Irrigation Control</p><button type="button" className={`toggle ${isOn ? 'on' : ''}`} aria-label={isOn ? 'Irrigation is on' : 'Irrigation is off'} onClick={() => setIsOn((currentValue) => !currentValue)}><span /></button></div><div className="irrigation-state">{isOn ? 'ON' : 'OFF'}</div><p className="subtle">{isOn ? 'Mock/local control only' : 'Automatic mode'}</p><p className="tiny-note">{isOn ? 'Frontend mock status: irrigation command queued locally; no backend connection yet.' : 'Next scheduled run: Apr 25, 06:00'}</p><button className="secondary-button" type="button" onClick={onOpenSettings}>Settings</button></Card>;
}

function AlertsPanel() {
  const navigate = useNavigate();

  return <Card className="alerts-panel"><div className="card-heading"><p className="kicker">Recent Alerts</p><button type="button" className="text-button" onClick={() => navigate('/alerts')}>View all</button></div><div className="alert-list">{alerts.map(alert => <div className="alert-row" key={alert.title}><span className={`alert-dot ${alert.tone}`} /><div><strong>{alert.title}</strong><small>{alert.detail}</small></div></div>)}</div></Card>;
}

function QuickActions() {
  const navigate = useNavigate();
  const [cameraNoticeOpen, setCameraNoticeOpen] = useState(false);

  const actions = [
    { label: 'View Camera Feed', onClick: () => setCameraNoticeOpen(true), icon: Activity },
    { label: 'Check Device Status', onClick: () => navigate('/devices'), icon: Wifi },
    { label: 'View Reports', onClick: () => navigate('/history'), icon: LayoutDashboard },
  ];

  return (
    <>
      <Card className="quick-actions">
        <div className="card-heading"><p className="kicker">Quick Actions</p></div>
        {actions.map(({ label, onClick, icon: Icon }) => (
          <button type="button" className="quick-action" key={label} onClick={onClick}>
            <span className="quick-icon"><Icon size={15} /></span>
            {label}
            <ChevronRight size={14} />
          </button>
        ))}
      </Card>

      {cameraNoticeOpen && (
        <>
          <div className="panel-overlay" onClick={() => setCameraNoticeOpen(false)} />
          <div className="camera-notice panel-card" aria-live="polite">
            <div className="panel-header">
              <strong>Camera feed</strong>
              <button type="button" className="small-close" onClick={() => setCameraNoticeOpen(false)}>Close</button>
            </div>
            <p>Camera functionality is not connected to a live backend yet. This is a frontend mock and the feature remains local-only until the real integration is available.</p>
          </div>
        </>
      )}
    </>
  );
}

function Dashboard() {
  const [selectedField, setSelectedField] = useState('North Field');
  const [fieldMenuOpen, setFieldMenuOpen] = useState(false);
  const navigate = useNavigate();

  return (
    <>
      <div className="page-intro">
        <div>
          <p className="eyebrow">{selectedField} · Device cluster 01</p>
          <h2>Farm overview</h2>
        </div>
        <div className="farm-select-wrap">
          <button type="button" className="farm-selector" onClick={() => setFieldMenuOpen((currentValue) => !currentValue)} aria-expanded={fieldMenuOpen}>
            {selectedField} <ChevronDown size={15} />
          </button>

          {fieldMenuOpen && (
            <div className="action-menu field-menu">
              <button type="button" onClick={() => { setSelectedField('North Field'); setFieldMenuOpen(false); }}>North Field</button>
              <button type="button" onClick={() => { setSelectedField('South Field'); setFieldMenuOpen(false); }}>South Field</button>
              <button type="button" onClick={() => { setSelectedField('Greenhouse'); setFieldMenuOpen(false); }}>Greenhouse</button>
            </div>
          )}
        </div>
      </div>

      <div className="dashboard-grid">
        <div className="main-column">
          <div className="hero-grid">
            <MoistureCard />
            <StatusCard />
            <FieldCard fieldName={selectedField} onSelect={() => navigate('/monitoring')} />
          </div>
          <Environment />
          <div className="lower-grid">
            <TrendCard />
            <IrrigationCard onOpenSettings={() => navigate('/settings')} />
          </div>
        </div>

        <aside className="right-column">
          <AlertsPanel />
          <QuickActions />
        </aside>
      </div>
    </>
  );
}

function SensorTile({ sensor }) {
  const Icon = sensor.icon;
  return <article className="live-sensor-tile"><span className={`live-sensor-icon ${sensor.tone}`}><Icon size={18} /></span><div className="live-sensor-copy"><p>{sensor.label}</p><span className="live-detail">{sensor.detail} · Updated just now</span></div><strong>{sensor.value}<small>{sensor.unit}</small></strong><span className={`live-badge ${sensor.tone}`}><span />{sensor.status}</span></article>;
}

function LiveMonitoring() {
  const [updated, setUpdated] = useState('just now');
  const [isIrrigationOn, setIrrigationOn] = useState(false);

  return <div className="monitoring-page"><div className="monitoring-header"><div><p className="eyebrow">North Field · 4 connected devices</p><h2>Live monitoring</h2><p className="subtle">A clear, real-time view of your field conditions.</p></div><div className="monitoring-actions"><span className="live-connection"><span className="live-pulse" />Live connection</span><button className="refresh-button" type="button" onClick={() => setUpdated('just now')}><RefreshCw size={15} />Refresh</button></div></div><section className="live-hero"><div className="live-hero-copy"><span className="live-kicker"><Radio size={14} />Current field signal</span><p>Soil moisture is <strong>optimal</strong></p><span>42% moisture is within the 35%–60% healthy range.</span><div className="live-hero-meta"><span><span className="status-dot healthy" />Updated {updated}</span><span>Sensor 01 · Online</span></div></div><div className="live-gauge"><div className="gauge-caption"><span>Soil moisture</span><strong>42%</strong></div><div className="gauge-track"><span className="gauge-safe" /><span className="gauge-value" /></div><div className="gauge-labels"><span>0%</span><span>35%</span><span>60%</span><span>100%</span></div></div></section><section className="live-section-heading"><div><h3>Field sensors</h3><p>Live readings from North Field Sensor 01</p></div><span>Last packet received 5 seconds ago</span></section><div className="live-sensor-grid">{liveSensors.map(sensor => <SensorTile key={sensor.label} sensor={sensor} />)}</div><div className="monitoring-lower"><section className="card device-health"><div className="card-heading"><div><p className="kicker"><Wifi size={16} /> Device health</p><p className="subtle">Connection across North Field</p></div><span className="live-badge healthy"><span />4 online</span></div><div className="device-row"><span className="device-orb"><Radio size={16} /></span><div><strong>North Field Sensor 01</strong><small>Primary environment sensor · Signal excellent</small></div><span className="device-time">Updated 5 sec ago</span></div><div className="device-row"><span className="device-orb"><Droplets size={16} /></span><div><strong>Irrigation Controller</strong><small>Automatic mode · Pump standing by</small></div><span className="device-time">Updated 8 sec ago</span></div></section><section className="card live-irrigation"><div className="card-heading"><p className="kicker"><Droplets size={16} /> Irrigation state</p><button type="button" className={`toggle ${isIrrigationOn ? 'on' : ''}`} aria-label={isIrrigationOn ? 'Irrigation is on' : 'Irrigation is off'} onClick={() => setIrrigationOn((currentValue) => !currentValue)}><span /></button></div><strong>{isIrrigationOn ? 'Enabled (mock)' : 'Standby'}</strong><p>{isIrrigationOn ? 'Frontend mock state: irrigation support is enabled locally, but no live backend command has been sent.' : 'Automation is ready. Watering starts only when the backend threshold rules require it.'}</p><span className="live-detail">Next schedule: Tomorrow, 06:00</span></section></div></div>;
}

function SummaryMetric({ label, value, detail, icon: Icon }) {
  return <div className="summary-metric card"><div className="summary-metric-header"><span className="summary-icon"><Icon size={16} /></span><span className="summary-kicker">{label}</span></div><strong>{value}</strong><small>{detail}</small></div>;
}

function HistoryChart({ records, metricKey }) {
  const metric = historyMetrics[metricKey];
  const values = records.map((record) => Number(record[metric.accessor]));
  const maxValue = Math.max(...values, 0);
  const minValue = Math.min(...values, 0);
  const range = maxValue - minValue || 1;

  const points = records.map((record, index) => {
    const x = (index / Math.max(records.length - 1, 1)) * 100;
    const normalized = (Number(record[metric.accessor]) - minValue) / range;
    const y = 84 - normalized * 70;
    return { x, y, value: Number(record[metric.accessor]) };
  });

  const linePath = points.map((point, index) => `${index === 0 ? 'M' : 'L'} ${point.x} ${point.y}`).join(' ');
  const areaPath = `${linePath} L 100 84 L 0 84 Z`;

  return <div className="history-chart"><svg viewBox="0 0 100 84" preserveAspectRatio="none" role="img" aria-label={`${metric.label} trend`}>
    <defs>
      <linearGradient id={`history-fill-${metricKey}`} x1="0" x2="0" y1="0" y2="1">
        <stop offset="0%" stopColor={metric.color} stopOpacity="0.35" />
        <stop offset="100%" stopColor={metric.color} stopOpacity="0.02" />
      </linearGradient>
    </defs>
    <path d={areaPath} fill={`url(#history-fill-${metricKey})`} />
    <path d={linePath} fill="none" stroke={metric.color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
  </svg><div className="history-chart-labels">{records.slice(0, 6).map((record, index) => <span key={record.id || index}>{record.time}</span>)}{records.length > 6 && <span>Latest</span>}</div></div>;
}

function HistoryPage() {
  const [selectedRange, setSelectedRange] = useState('7d');
  const [selectedMetric, setSelectedMetric] = useState('soilMoisture');
  const [selectedField, setSelectedField] = useState('North Field');
  const [records, setRecords] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    setIsLoading(true);
    setError('');

    const timer = window.setTimeout(() => {
      if (!active) {
        return;
      }

      try {
        const allRecords = mockHistoryData.filter((record) => record.field === selectedField);
        const rangeDays = selectedRange === '24h' ? 1 : selectedRange === '7d' ? 7 : 30;
        const cutoff = new Date();
        cutoff.setDate(cutoff.getDate() - rangeDays);

        const filteredRecords = allRecords.filter((record) => new Date(record.date) >= cutoff || record.date === cutoff.toISOString().slice(0, 10));
        setRecords(filteredRecords.slice(-20));
      } catch (loadError) {
        setError('Unable to load historical data. Please try again.');
      } finally {
        setIsLoading(false);
      }
    }, 300);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [selectedField, selectedRange]);

  const resetFilters = () => {
    setSelectedRange('7d');
    setSelectedField('North Field');
    setSelectedMetric('soilMoisture');
  };

  const summary = records.reduce((accumulator, record) => {
    accumulator.soilMoisture += record.soilMoisture;
    accumulator.temperature += record.temperature;
    accumulator.humidity += record.humidity;
    accumulator.rainfall += record.rainfall;
    accumulator.rainEvents += record.rainfall > 0 ? 1 : 0;
    return accumulator;
  }, { soilMoisture: 0, temperature: 0, humidity: 0, rainfall: 0, rainEvents: 0 });

  const summaryData = records.length ? {
    soilMoisture: `${(summary.soilMoisture / records.length).toFixed(1)}%`,
    temperature: `${(summary.temperature / records.length).toFixed(1)}°C`,
    humidity: `${(summary.humidity / records.length).toFixed(1)}%`,
    rainfall: `${summary.rainfall.toFixed(1)} mm`,
    rainEvents: `${summary.rainEvents} events`,
  } : { soilMoisture: '—', temperature: '—', humidity: '—', rainfall: '—', rainEvents: '—' };

  return <div className="history-page"><div className="page-intro page-intro-history"><div><p className="eyebrow">North Field · Historical records</p><h2>Historical data</h2><p className="subtle">Review recent field conditions to understand how moisture, temperature, and rainfall have changed over time.</p></div><button className="farm-selector">North Field <ChevronDown size={15} /></button></div><div className="history-controls card"><div className="range-segment" aria-label="Date range selector">{historyRanges.map((range) => <button key={range.key} className={`range-button ${selectedRange === range.key ? 'active' : ''}`} onClick={() => setSelectedRange(range.key)}>{range.label}</button>)}</div><div className="history-filter-actions"><label className="history-select"><span>Metric</span><select value={selectedMetric} onChange={(event) => setSelectedMetric(event.target.value)}><option value="soilMoisture">Soil moisture</option><option value="temperature">Temperature</option><option value="humidity">Humidity</option></select></label><label className="history-select"><span>Field</span><select value={selectedField} onChange={(event) => setSelectedField(event.target.value)}>{historyFields.map((field) => <option key={field} value={field}>{field}</option>)}</select></label><button className="secondary-button history-reset" onClick={resetFilters}><RefreshCw size={14} />Clear</button></div></div>{isLoading ? <div className="history-state card"><span className="state-spinner" /><div><strong>Loading historical data</strong><p>Gathering recent sensor readings for the selected field.</p></div></div> : error ? <div className="history-state card history-state-error"><div className="state-icon"><CloudRain size={18} /></div><div><strong>Unable to load historical data</strong><p>{error}</p><button className="secondary-button" onClick={() => setError('')}>Try again</button></div></div> : records.length === 0 ? <div className="history-state card history-state-empty"><div className="state-icon"><CalendarRange size={18} /></div><div><strong>No data available</strong><p>There are no historical readings for this field and time range.</p><button className="secondary-button" onClick={resetFilters}>Reset filters</button></div></div> : <><div className="summary-grid"><SummaryMetric label="Avg. soil moisture" value={summaryData.soilMoisture} detail="Healthy range" icon={Droplets} /><SummaryMetric label="Avg. temperature" value={summaryData.temperature} detail="Field average" icon={Thermometer} /><SummaryMetric label="Avg. humidity" value={summaryData.humidity} detail="Ambient moisture" icon={Gauge} /><SummaryMetric label="Rainfall" value={summaryData.rainfall} detail={summaryData.rainEvents} icon={CloudRain} /></div><section className="card history-trend-card"><div className="card-heading"><div><p className="kicker"><TrendingUp size={15} /> Historical trend</p><p className="subtle">{historyMetrics[selectedMetric].label} over the selected period</p></div><span className="range-pill">{selectedField}</span></div><HistoryChart records={records} metricKey={selectedMetric} /></section><section className="card history-table-card"><div className="card-heading"><div><p className="kicker"><Leaf size={15} /> Recent readings</p><p className="subtle">Latest measurements from {selectedField}</p></div><span className="range-pill">{selectedRange === '24h' ? '24H' : selectedRange === '7d' ? '7D' : '30D'}</span></div><div className="history-table-wrap"><table className="history-table"><thead><tr><th>Date</th><th>Time</th><th>Soil moisture</th><th>Temperature</th><th>Humidity</th><th>Pressure</th><th>Light</th><th>Rainfall</th></tr></thead><tbody>{records.slice().reverse().slice(0, 5).map((record) => <tr key={record.id}><td>{record.date}</td><td>{record.time}</td><td>{record.soilMoisture}%</td><td>{record.temperature}°C</td><td>{record.humidity}%</td><td>{record.pressure} hPa</td><td>{record.light}%</td><td>{record.rainfall > 0 ? `${record.rainfall} mm` : '0 mm'}</td></tr>)}</tbody></table></div></section></>}</div>;
}

function AlertSummaryCard({ label, value, tone, icon: Icon }) {
  return <div className="alert-summary-card card"><div className="summary-metric-header"><span className={`summary-icon ${tone}`}><Icon size={16} /></span><span className="summary-kicker">{label}</span></div><strong>{value}</strong><small>{tone === 'critical' ? 'Needs attention' : tone === 'warning' ? 'Monitor closely' : tone === 'healthy' ? 'Stable' : 'Resolved'}</small></div>;
}

function AlertsPage() {
  const [alertsList, setAlertsList] = useState([]);
  const [severityFilter, setSeverityFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [fieldFilter, setFieldFilter] = useState('all');
  const [selectedAlertId, setSelectedAlertId] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    setIsLoading(true);
    setError('');

    const timer = window.setTimeout(() => {
      if (!active) return;
      try {
        setAlertsList(mockAlertData);
        setSelectedAlertId(mockAlertData[0]?.id ?? null);
      } catch (loadError) {
        setError('Unable to load alert feed. Please try again.');
      } finally {
        setIsLoading(false);
      }
    }, 250);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, []);

  const visibleAlerts = alertsList.filter((alert) => {
    const matchesSeverity = severityFilter === 'all' || alert.severity === severityFilter;
    const matchesStatus = statusFilter === 'all' || alert.status === statusFilter;
    const matchesField = fieldFilter === 'all' || alert.field === fieldFilter;
    return matchesSeverity && matchesStatus && matchesField;
  });

  useEffect(() => {
    if (!visibleAlerts.length) {
      setSelectedAlertId(null);
      return;
    }

    const currentSelectionExists = visibleAlerts.some((alert) => alert.id === selectedAlertId);
    if (!currentSelectionExists) {
      setSelectedAlertId(visibleAlerts[0].id);
    }
  }, [visibleAlerts, selectedAlertId]);

  const selectedAlert = visibleAlerts.find((alert) => alert.id === selectedAlertId) || visibleAlerts[0] || null;

  const activeAlerts = alertsList.filter((alert) => alert.status === 'active').length;
  const warnings = alertsList.filter((alert) => alert.severity === 'warning').length;
  const criticalAlerts = alertsList.filter((alert) => alert.severity === 'critical').length;
  const resolvedAlerts = alertsList.filter((alert) => alert.status === 'resolved').length;

  const updateAlertStatus = (alertId, nextStatus) => {
    setAlertsList((currentAlerts) => currentAlerts.map((alert) => alert.id === alertId ? { ...alert, status: nextStatus } : alert));
  };

  const clearFilters = () => {
    setSeverityFilter('all');
    setStatusFilter('all');
    setFieldFilter('all');
  };

  return <div className="alerts-page"><div className="page-intro page-intro-history"><div><p className="eyebrow">North Field · Farm notifications</p><h2>Alerts</h2><p className="subtle">Review recent and historical farm alerts so you can respond quickly to changing field conditions.</p></div><button className="farm-selector">North Field <ChevronDown size={15} /></button></div><div className="summary-grid alert-summary-grid"><AlertSummaryCard label="Active alerts" value={activeAlerts} tone="critical" icon={ShieldAlert} /><AlertSummaryCard label="Warnings" value={warnings} tone="warning" icon={Bell} /><AlertSummaryCard label="Critical alerts" value={criticalAlerts} tone="critical" icon={Flame} /><AlertSummaryCard label="Resolved alerts" value={resolvedAlerts} tone="healthy" icon={Check} /></div><div className="alert-filter-bar card"><div className="alert-filter-group"><span className="alert-filter-label">Severity</span><div className="chip-row">{alertSeverityOptions.map((option) => <button key={option} className={`chip ${severityFilter === option ? 'active' : ''}`} onClick={() => setSeverityFilter(option)}>{option === 'all' ? 'All alerts' : option === 'critical' ? 'Critical' : option === 'warning' ? 'Warning' : 'Informational'}</button>)}</div></div><div className="alert-filter-group compact"><label className="history-select"><span>Status</span><select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>{alertStatusOptions.map((option) => <option key={option} value={option}>{option === 'all' ? 'All status' : option === 'active' ? 'Active' : 'Resolved'}</option>)}</select></label><label className="history-select"><span>Field</span><select value={fieldFilter} onChange={(event) => setFieldFilter(event.target.value)}><option value="all">All fields</option>{alertFields.map((field) => <option key={field} value={field}>{field}</option>)}</select></label><button className="secondary-button history-reset" onClick={clearFilters}><RefreshCw size={14} />Clear filters</button></div></div>{isLoading ? <div className="history-state card"><span className="state-spinner" /><div><strong>Loading alerts</strong><p>Checking field notifications and safety events.</p></div></div> : error ? <div className="history-state card history-state-error"><div className="state-icon"><Bell size={18} /></div><div><strong>Unable to load alerts</strong><p>{error}</p><button className="secondary-button" onClick={() => setError('')}>Try again</button></div></div> : visibleAlerts.length === 0 ? <div className="history-state card history-state-empty"><div className="state-icon"><Check size={18} /></div><div><strong>No alerts found</strong><p>There are no notifications matching the current filters.</p><button className="secondary-button" onClick={clearFilters}>Reset filters</button></div></div> : <div className="alert-layout"><div className="alert-list-panel card"><div className="page-list-header"><div><p className="kicker"><Bell size={15} /> Recent activity</p></div><span className="range-pill">{visibleAlerts.length} alerts</span></div>{visibleAlerts.map((alert) => <button type="button" key={alert.id} className={`alert-item ${selectedAlert && selectedAlert.id === alert.id ? 'selected' : ''}`} onClick={() => setSelectedAlertId(alert.id)}><div className="alert-item-top"><span className={`alert-type ${alert.severity}`}>{alert.severity}</span><span className={`alert-status ${alert.status}`}>{alert.status}</span></div><strong>{alert.title}</strong><div className="alert-meta"><span>{alert.field}</span><span>{alert.device}</span><span>{alert.date}</span><span>{alert.time}</span></div><p>{alert.description}</p></button>)}</div><aside className="alert-detail-panel card"><div className="alert-detail-header"><p className="kicker"><ShieldAlert size={15} /> Alert details</p>{selectedAlert && <span className={`alert-type ${selectedAlert.severity}`}>{selectedAlert.severity}</span>}</div>{selectedAlert ? <><div className="alert-detail-main"><strong>{selectedAlert.title}</strong><div className="alert-meta detail-meta"><span>{selectedAlert.field}</span><span>{selectedAlert.device}</span><span>{selectedAlert.source}</span></div><div className="alert-date-block"><span>{selectedAlert.date}</span><span>{selectedAlert.time}</span></div><p>{selectedAlert.description}</p><div className="alert-detail-note"><span>Recommended action</span><p>{selectedAlert.action}</p></div></div><div className="alert-action-row"><button className="secondary-button" onClick={() => updateAlertStatus(selectedAlert.id, selectedAlert.status === 'active' ? 'resolved' : 'active')}>{selectedAlert.status === 'active' ? 'Mark resolved' : 'Reopen alert'}</button><button className="ghost-button" onClick={() => updateAlertStatus(selectedAlert.id, 'resolved')}>Dismiss</button></div></> : <p className="subtle">Select an alert to inspect details.</p>}</aside></div>}</div>;
}

function DeviceSummaryCard({ label, value, tone, icon: Icon }) {
  return <div className="alert-summary-card card"><div className="summary-metric-header"><span className={`summary-icon ${tone}`}><Icon size={16} /></span><span className="summary-kicker">{label}</span></div><strong>{value}</strong><small>{tone === 'online' ? 'Connected' : tone === 'offline' ? 'Needs attention' : tone === 'warning' ? 'Review soon' : 'Tracked'}</small></div>;
}

function DevicesPage() {
  const [devices, setDevices] = useState([]);
  const [statusFilter, setStatusFilter] = useState('all');
  const [fieldFilter, setFieldFilter] = useState('all');
  const [selectedDeviceId, setSelectedDeviceId] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    setIsLoading(true);
    setError('');

    const timer = window.setTimeout(() => {
      if (!active) return;
      try {
        setDevices(mockDeviceData);
        setSelectedDeviceId(mockDeviceData[0]?.id ?? null);
      } catch (loadError) {
        setError('Unable to load device list. Please try again.');
      } finally {
        setIsLoading(false);
      }
    }, 250);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, []);

  const visibleDevices = devices.filter((device) => {
    const matchesStatus = statusFilter === 'all' || device.status === statusFilter;
    const matchesField = fieldFilter === 'all' || device.field === fieldFilter;
    return matchesStatus && matchesField;
  });

  useEffect(() => {
    if (!visibleDevices.length) {
      setSelectedDeviceId(null);
      return;
    }

    const currentSelectionExists = visibleDevices.some((device) => device.id === selectedDeviceId);
    if (!currentSelectionExists) {
      setSelectedDeviceId(visibleDevices[0].id);
    }
  }, [visibleDevices, selectedDeviceId]);

  const selectedDevice = visibleDevices.find((device) => device.id === selectedDeviceId) || visibleDevices[0] || null;

  const totalDevices = devices.length;
  const onlineDevices = devices.filter((device) => device.status === 'online').length;
  const offlineDevices = devices.filter((device) => device.status === 'offline').length;
  const attentionDevices = devices.filter((device) => device.status === 'needs-attention').length;

  const refreshDeviceStatus = (deviceId) => {
    setDevices((currentDevices) => currentDevices.map((device) => device.id === deviceId ? { ...device, lastSeen: 'just now', health: 'Refreshed' } : device));
  };

  const reconnectDevice = (deviceId) => {
    setDevices((currentDevices) => currentDevices.map((device) => device.id === deviceId ? { ...device, status: 'online', signal: '78%', lastSeen: 'just now', health: 'Reconnected', operatingState: 'Monitoring' } : device));
  };

  const resetFilters = () => {
    setStatusFilter('all');
    setFieldFilter('all');
  };

  return <div className="devices-page"><div className="page-intro page-intro-history"><div><p className="eyebrow">North Field · Connected equipment</p><h2>Devices</h2><p className="subtle">This page shows the connected sensors and farm equipment reporting in from the field.</p></div><button className="farm-selector">North Field <ChevronDown size={15} /></button></div><div className="summary-grid alert-summary-grid"><DeviceSummaryCard label="Total devices" value={totalDevices} tone="tracked" icon={Wifi} /><DeviceSummaryCard label="Online" value={onlineDevices} tone="online" icon={ShieldCheck} /><DeviceSummaryCard label="Offline" value={offlineDevices} tone="offline" icon={ShieldAlert} /><DeviceSummaryCard label="Needs attention" value={attentionDevices} tone="warning" icon={Bell} /></div><div className="alert-filter-bar card"><div className="alert-filter-group compact"><label className="history-select"><span>Status</span><select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}><option value="all">All devices</option><option value="online">Online</option><option value="offline">Offline</option><option value="needs-attention">Needs attention</option></select></label><label className="history-select"><span>Field</span><select value={fieldFilter} onChange={(event) => setFieldFilter(event.target.value)}><option value="all">All fields</option><option value="North Field">North Field</option><option value="South Field">South Field</option><option value="Greenhouse">Greenhouse</option><option value="Irrigation Bay">Irrigation Bay</option></select></label><button className="secondary-button history-reset" onClick={resetFilters}><RefreshCw size={14} />Clear filters</button></div></div>{isLoading ? <div className="history-state card"><span className="state-spinner" /><div><strong>Loading devices</strong><p>Checking the farm network and current device health.</p></div></div> : error ? <div className="history-state card history-state-error"><div className="state-icon"><Wifi size={18} /></div><div><strong>Unable to load devices</strong><p>{error}</p><button className="secondary-button" onClick={() => setError('')}>Try again</button></div></div> : visibleDevices.length === 0 ? <div className="history-state card history-state-empty"><div className="state-icon"><Wifi size={18} /></div><div><strong>No devices found</strong><p>No devices match the current filters.</p><button className="secondary-button" onClick={resetFilters}>Reset filters</button></div></div> : <div className="device-layout"><div className="device-list-panel card"><div className="page-list-header"><div><p className="kicker"><Wifi size={15} /> Connected devices</p></div><span className="range-pill">{visibleDevices.length} shown</span></div>{visibleDevices.map((device) => <button type="button" key={device.id} className={`device-item ${selectedDevice && selectedDevice.id === device.id ? 'selected' : ''}`} onClick={() => setSelectedDeviceId(device.id)}><div className="device-item-top"><div className="device-title-wrap"><span className="device-icon"><Wifi size={16} /></span><div><strong>{device.name}</strong><small>{device.type}</small></div></div><span className={`device-state ${device.status}`}>{device.status === 'online' ? 'Online' : device.status === 'offline' ? 'Offline' : 'Needs attention'}</span></div><div className="device-meta-row"><span>{device.field}</span><span>{device.id}</span><span>Last seen {device.lastSeen}</span></div><div className="device-tags"><span>{device.signal} signal</span><span>{device.health}</span>{device.battery !== 'N/A' && <span>{device.battery} battery</span>}</div></button>)}</div><aside className="device-detail-panel card"><div className="alert-detail-header"><p className="kicker"><ShieldCheck size={15} /> Device details</p>{selectedDevice && <span className={`device-state ${selectedDevice.status}`}>{selectedDevice.status === 'online' ? 'Online' : selectedDevice.status === 'offline' ? 'Offline' : 'Needs attention'}</span>}</div>{selectedDevice ? <><div className="alert-detail-main"><strong>{selectedDevice.name}</strong><div className="alert-meta detail-meta"><span>{selectedDevice.type}</span><span>{selectedDevice.field}</span><span>{selectedDevice.id}</span></div><div className="device-detail-grid"><div><span>Signal</span><strong>{selectedDevice.signal}</strong></div><div><span>Last update</span><strong>{selectedDevice.lastSeen}</strong></div><div><span>Battery</span><strong>{selectedDevice.battery}</strong></div><div><span>State</span><strong>{selectedDevice.operatingState}</strong></div></div><div className="alert-detail-note"><span>Capabilities</span><p>{selectedDevice.capabilities.join(' · ')}</p></div><div className="alert-detail-note"><span>Notes</span><p>{selectedDevice.notes}</p></div></div><div className="alert-action-row"><button className="secondary-button" onClick={() => refreshDeviceStatus(selectedDevice.id)}>Refresh status</button>{selectedDevice.status === 'offline' && <button className="ghost-button" onClick={() => reconnectDevice(selectedDevice.id)}>Reconnect</button>}</div></> : <p className="subtle">Select a device to inspect details.</p>}</aside></div>}</div>;
}

const defaultSettings = {
  farmName: 'North Field',
  fieldName: 'North Field',
  fieldArea: '12.4',
  unitSystem: 'Metric',
  irrigationEnabled: true,
  moisturePumpOn: 35,
  moisturePumpOff: 55,
  rainAwareIrrigation: true,
  irrigationMode: 'Automatic',
  minSoilMoisture: 32,
  maxTemperature: 30,
  rainfallAlertThreshold: 15,
  smokeAlertEnabled: true,
  enableFarmAlerts: true,
  criticalAlerts: true,
  warningAlerts: true,
  deviceOfflineAlerts: true,
};

function ToggleRow({ label, description, checked, onChange, icon: Icon }) {
  return <div className="settings-toggle-row"><div className="settings-toggle-copy"><span className="settings-toggle-icon"><Icon size={15} /></span><div><strong>{label}</strong><small>{description}</small></div></div><button type="button" className={`settings-toggle ${checked ? 'on' : ''}`} onClick={onChange} aria-pressed={checked} aria-label={label}><span /></button></div>;
}

function SettingsPage({ dark, onThemeToggle }) {
  const [settings, setSettings] = useState(() => {
    const savedSettings = window.localStorage.getItem('soft-agri-settings');
    if (!savedSettings) {
      return defaultSettings;
    }

    try {
      return { ...defaultSettings, ...JSON.parse(savedSettings) };
    } catch (error) {
      return defaultSettings;
    }
  });
  const [saveState, setSaveState] = useState('idle');

  useEffect(() => {
    window.localStorage.setItem('soft-agri-settings', JSON.stringify(settings));
  }, [settings]);

  const updateSetting = (key, value) => {
    setSettings((currentSettings) => ({ ...currentSettings, [key]: value }));
    setSaveState('idle');
  };

  const handleSave = () => {
    setSaveState('saving');
    window.setTimeout(() => {
      setSaveState('saved');
      window.setTimeout(() => setSaveState('idle'), 1800);
    }, 250);
  };

  const handleReset = () => {
    setSettings(defaultSettings);
    setSaveState('reset');
    window.setTimeout(() => setSaveState('idle'), 1200);
  };

  return <div className="settings-page"><div className="page-intro page-intro-history"><div><p className="eyebrow">North Field · System configuration</p><h2>Settings</h2><p className="subtle">Adjust the farm preferences, irrigation automation, alerts, and device behavior for your current field.</p></div><button className="farm-selector">North Field <ChevronDown size={15} /></button></div><div className="settings-grid"><div className="settings-column"><section className="card settings-card"><div className="card-heading"><p className="kicker"><Leaf size={16} /> Farm / field settings</p></div><div className="settings-form-grid"><label className="settings-field"><span>Farm name</span><input type="text" value={settings.farmName} onChange={(event) => updateSetting('farmName', event.target.value)} /></label><label className="settings-field"><span>Field</span><select value={settings.fieldName} onChange={(event) => updateSetting('fieldName', event.target.value)}><option value="North Field">North Field</option><option value="South Field">South Field</option><option value="Greenhouse">Greenhouse</option><option value="Irrigation Bay">Irrigation Bay</option></select></label><label className="settings-field"><span>Field area</span><div className="field-area-input"><input type="number" min="0" step="0.1" value={settings.fieldArea} onChange={(event) => updateSetting('fieldArea', event.target.value)} /><span>ha</span></div></label><label className="settings-field"><span>Measurement unit</span><select value={settings.unitSystem} onChange={(event) => updateSetting('unitSystem', event.target.value)}><option value="Metric">Metric</option><option value="Imperial">Imperial</option></select></label></div></section><section className="card settings-card"><div className="card-heading"><p className="kicker"><Droplets size={16} /> Irrigation settings</p></div><div className="settings-form-grid"><ToggleRow label="Automatic irrigation" description="Allow the farm to manage irrigation schedules automatically." checked={settings.irrigationEnabled} onChange={() => updateSetting('irrigationEnabled', !settings.irrigationEnabled)} icon={Droplets} /><label className="settings-field"><span>Moisture pump on threshold</span><div className="field-area-input"><input type="number" min="0" max="100" value={settings.moisturePumpOn} onChange={(event) => updateSetting('moisturePumpOn', Number(event.target.value))} /><span>%</span></div></label><label className="settings-field"><span>Moisture pump off threshold</span><div className="field-area-input"><input type="number" min="0" max="100" value={settings.moisturePumpOff} onChange={(event) => updateSetting('moisturePumpOff', Number(event.target.value))} /><span>%</span></div></label><ToggleRow label="Rain-aware irrigation" description="Pause irrigation when the weather station detects rainfall." checked={settings.rainAwareIrrigation} onChange={() => updateSetting('rainAwareIrrigation', !settings.rainAwareIrrigation)} icon={CloudRain} /><label className="settings-field"><span>Operating mode</span><select value={settings.irrigationMode} onChange={(event) => updateSetting('irrigationMode', event.target.value)}><option value="Automatic">Automatic</option><option value="Manual">Manual</option><option value="Scheduled">Scheduled</option></select></label></div></section><section className="card settings-card"><div className="card-heading"><p className="kicker"><Gauge size={16} /> Sensor / alert thresholds</p></div><div className="settings-form-grid"><label className="settings-field"><span>Minimum soil moisture</span><div className="field-area-input"><input type="number" min="0" max="100" value={settings.minSoilMoisture} onChange={(event) => updateSetting('minSoilMoisture', Number(event.target.value))} /><span>%</span></div></label><label className="settings-field"><span>Maximum temperature</span><div className="field-area-input"><input type="number" min="0" max="60" value={settings.maxTemperature} onChange={(event) => updateSetting('maxTemperature', Number(event.target.value))} /><span>°C</span></div></label><label className="settings-field"><span>Rain alert threshold</span><div className="field-area-input"><input type="number" min="0" max="100" value={settings.rainfallAlertThreshold} onChange={(event) => updateSetting('rainfallAlertThreshold', Number(event.target.value))} /><span>mm</span></div></label><ToggleRow label="Smoke / fire alerts" description="Trigger an alert when smoke or fire thresholds are reached." checked={settings.smokeAlertEnabled} onChange={() => updateSetting('smokeAlertEnabled', !settings.smokeAlertEnabled)} icon={Flame} /></div></section></div><div className="settings-column"><section className="card settings-card"><div className="card-heading"><p className="kicker"><Bell size={16} /> Notification settings</p></div><div className="settings-form-grid"><ToggleRow label="Enable farm alerts" description="Display and send farm alert notifications." checked={settings.enableFarmAlerts} onChange={() => updateSetting('enableFarmAlerts', !settings.enableFarmAlerts)} icon={Bell} /><ToggleRow label="Critical alerts" description="Show urgent notifications for critical farm events." checked={settings.criticalAlerts} onChange={() => updateSetting('criticalAlerts', !settings.criticalAlerts)} icon={ShieldAlert} /><ToggleRow label="Warning alerts" description="Alert when a device or environment is out of range." checked={settings.warningAlerts} onChange={() => updateSetting('warningAlerts', !settings.warningAlerts)} icon={Bell} /><ToggleRow label="Device offline notifications" description="Notify when a sensor or device loses connectivity." checked={settings.deviceOfflineAlerts} onChange={() => updateSetting('deviceOfflineAlerts', !settings.deviceOfflineAlerts)} icon={Wifi} /></div></section><section className="card settings-card"><div className="card-heading"><p className="kicker"><Wifi size={16} /> Device / system information</p></div><div className="settings-system-grid"><div className="settings-system-item"><span>Connected devices</span><strong>6</strong></div><div className="settings-system-item"><span>System status</span><strong>Healthy</strong></div><div className="settings-system-item"><span>Application version</span><strong>0.1.0</strong></div><div className="settings-system-item"><span>Last sync</span><strong>2 min ago</strong></div></div></section><section className="card settings-card settings-actions-card"><div className="settings-actions"><button className="primary-button" onClick={handleSave}>{saveState === 'saving' ? 'Saving...' : saveState === 'saved' ? 'Saved' : 'Save settings'}</button><button className="secondary-button" onClick={handleReset}>Reset</button></div>{saveState === 'saved' && <p className="settings-save-status">Changes saved locally in the app.</p>}{saveState === 'reset' && <p className="settings-save-status">Settings reset to default values.</p>}</section></div></div></div>;
}

function Placeholder({ title }) { return <div className="placeholder"><span className="placeholder-icon"><Leaf size={20} /></span><h2>{title}</h2><p>This section is part of the next implementation phase. The app shell and design system are ready for it.</p></div>; }

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [headerMenu, setHeaderMenu] = useState(null);
  const [dark, setDark] = useState(() => window.localStorage.getItem('soft-agri-theme') === 'dark');

  useEffect(() => { window.localStorage.setItem('soft-agri-theme', dark ? 'dark' : 'light'); }, [dark]);
  useEffect(() => {
    const handleEscape = (event) => {
      if (event.key === 'Escape') {
        setMenuOpen(false);
        setHeaderMenu(null);
      }
    };

    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  }, []);

  return <div className={`app-shell ${dark ? 'theme-dark' : ''}`}><Sidebar open={menuOpen} onClose={() => setMenuOpen(false)} />{menuOpen && <button className="scrim" onClick={() => setMenuOpen(false)} aria-label="Close navigation" /> }{headerMenu && <button className="panel-overlay" onClick={() => setHeaderMenu(null)} aria-label="Close help and profile panels" /> }<main className="main"><Header onMenu={() => setMenuOpen(true)} dark={dark} onThemeToggle={() => setDark(current => !current)} helpOpen={headerMenu === 'help'} profileOpen={headerMenu === 'profile'} onHelpToggle={() => setHeaderMenu((currentValue) => currentValue === 'help' ? null : 'help')} onProfileToggle={() => setHeaderMenu((currentValue) => currentValue === 'profile' ? null : 'profile')} onClosePanels={() => setHeaderMenu(null)} /><div className="content"><Routes><Route path="/" element={<Dashboard />} /><Route path="/monitoring" element={<LiveMonitoring />} /><Route path="/history" element={<HistoryPage />} /><Route path="/alerts" element={<AlertsPage />} /><Route path="/devices" element={<DevicesPage />} /><Route path="/settings" element={<SettingsPage dark={dark} onThemeToggle={() => setDark(current => !current)} />} /></Routes></div></main></div>;
}

createRoot(document.getElementById('root')).render(<React.StrictMode><BrowserRouter><App /></BrowserRouter></React.StrictMode>);
